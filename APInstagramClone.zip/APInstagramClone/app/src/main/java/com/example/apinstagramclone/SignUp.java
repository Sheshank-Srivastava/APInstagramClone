package com.example.apinstagramclone;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.parse.GetCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;

public class SignUp extends AppCompatActivity {

    private TextView txtGetData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtGetData = findViewById(R.id.txtDataServer);

        txtGetData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ParseQuery<ParseObject> parseQuary = ParseQuery.getQuery("KickBoxer");
                parseQuary.getInBackground("Lu6HZ4okHA", new GetCallback<ParseObject>() {
                    @Override
                    public void done(ParseObject object, ParseException e) {
                        if(object != null && e == null){

                            txtGetData.setText(object.get("punch_speed").toString());
                        }

                    }
                });
            }
        });
    }
}
